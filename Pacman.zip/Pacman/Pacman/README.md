# PacMan-Python
Pacman game written in python 3.8 version using Pygame
Click Play to start game. 
Use Directional buttons on board to play game. 
Select Exit to quit the console. 
